package observer_final;

import java.util.ArrayList;

public class DecimalToBaseConverter {
	public int decimalvalue=0;
	ArrayList<Observer> observers=new ArrayList<Observer>();
	void addObserver(Observer obs) {
		observers.add(obs);
	}
	void removeObserver(Observer obs) {
		observers.remove(obs);
	}
	void notifyObserver() {
		for(Observer observer : observers) {
			observer.update(this.decimalvalue);
		}
	}
	void setDecimalValue(int value) {
		this.decimalvalue=value;
		notifyObserver();
	}
}
