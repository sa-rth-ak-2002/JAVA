package observer_final;

public interface Observer {
	void update(int value);
}
