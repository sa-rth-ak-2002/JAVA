package observer_final;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

public class MainDisplay {
	public MainDisplay(){
		DecimalToBaseConverter sub=new DecimalToBaseConverter();
		OctDisplay octobserver=new OctDisplay(sub);
		HexDisplay hexobserver=new HexDisplay(sub);
		BinDisplay binobserver=new BinDisplay(sub);
		
		JFrame jf=new JFrame();
		jf.setBounds(200, 200, 400, 200);
		jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jf.setLayout(null);
		
		JLabel l1=new JLabel("Enter Decimal Number: ");
		l1.setBounds(10, 10, 150, 20);
		l1.setVisible(true);
		jf.add(l1);
		
		JTextField dec=new JTextField("0");
		dec.setBounds(160, 10, 50, 20);
		dec.setVisible(true);
		jf.add(dec);
		
		JCheckBox b1=new JCheckBox("Binary Representation: ");
		b1.setBounds(10, 50, 200, 20);
		b1.setVisible(true);
		jf.add(b1);
		
		JCheckBox o1=new JCheckBox("Octal Representation: ");
		o1.setBounds(10, 80, 200, 20);
		o1.setVisible(true);
		jf.add(o1);
		
		JCheckBox h1=new JCheckBox("Hexadecimal Representation: ");
		h1.setBounds(10, 110, 200, 20);
		h1.setVisible(true);
		jf.add(h1);
		
		JButton jb=new JButton("Convert");
		jb.setBounds(220, 10, 150, 20);
		jb.setVisible(true);
		jf.add(jb);
		
		JLabel blabel=new JLabel("");
		blabel.setBounds(210, 50, 200, 20);
		blabel.setVisible(true);
		jf.add(blabel);
		JLabel octlabel=new JLabel("");
		octlabel.setBounds(210, 80, 200, 20);
		octlabel.setVisible(true);
		jf.add(octlabel);
		JLabel hexlabel=new JLabel("");
		hexlabel.setBounds(210, 110, 200, 20);
		hexlabel.setVisible(true);
		jf.add(hexlabel);
		
		jb.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				int t=Integer.parseInt(dec.getText());
				sub.setDecimalValue(t);
				
				if(b1.isSelected()) {
					blabel.setText(binobserver.binValue);
				}
				else {
					blabel.setText("");
				}
				if(o1.isSelected()) {
					octlabel.setText(octobserver.octValue);
				}
				else {
					octlabel.setText("");
				}
				if(h1.isSelected()) {
					hexlabel.setText(hexobserver.hexValue);
				}
				else {
					hexlabel.setText("");
				}
			}
			
		});
		
		jf.setVisible(true);
	}
	
	public static void main(String args[]) {
		SwingUtilities.invokeLater(()->	new MainDisplay());
	}
}
