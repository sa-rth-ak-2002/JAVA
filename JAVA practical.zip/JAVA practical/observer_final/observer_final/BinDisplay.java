package observer_final;

public class BinDisplay implements Observer{
	String binValue;
	public BinDisplay(DecimalToBaseConverter subject) {
		this.binValue=Integer.toBinaryString(subject.decimalvalue);
		subject.addObserver(this);
	}
	@Override
	public void update(int value) {
		this.binValue=Integer.toBinaryString(value);
	}
}
