package observer_final;


public class OctDisplay implements Observer{
	String octValue;
	public OctDisplay(DecimalToBaseConverter subject) {
		this.octValue=Integer.toOctalString(subject.decimalvalue);
		subject.addObserver(this);
	}
	@Override
	public void update(int value) {
		this.octValue=Integer.toOctalString(value);
	}
	
}