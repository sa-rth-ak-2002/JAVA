package observer_final;

public class HexDisplay implements Observer{
	String hexValue;
	public HexDisplay(DecimalToBaseConverter subject) {
		this.hexValue=Integer.toHexString(subject.decimalvalue);
		subject.addObserver(this);
	}
	@Override
	public void update(int value) {
		this.hexValue=Integer.toHexString(value).toUpperCase();
	}
	
}
