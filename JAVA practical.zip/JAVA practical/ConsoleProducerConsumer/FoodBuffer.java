public class FoodBuffer {
    private final Food[] buffer;
    private int count = 0;

    public FoodBuffer(int size) {
        buffer = new Food[size];
    }

    public synchronized void produce(Food food) throws InterruptedException {
        while (count == buffer.length) {
            wait();
        }
        buffer[count++] = food;
        System.out.println("Produced: " + food);
        notifyAll();
    }

    public synchronized Food consume() throws InterruptedException {
        while (count == 0) {
            wait();
        }
        Food food = buffer[--count];
        buffer[count] = null;
        System.out.println("Consumed: " + food);
        notifyAll();
        return food;
    }

    public synchronized void displayBuffer() {
        System.out.print("Buffer: ");
        for (int i = 0; i < buffer.length; i++) {
            System.out.print((buffer[i] != null ? buffer[i] : "EMPTY") + " ");
        }
        System.out.println();
    }
}