public class Consumer extends Thread {
    private final FoodBuffer buffer;

    public Consumer(FoodBuffer buffer) {
        this.buffer = buffer;
    }

    public void run() {
        try {
            while (true) {
                buffer.consume();
                buffer.displayBuffer();
                Thread.sleep((int)(Math.random() * 3000));
            }
        } catch (InterruptedException e) {
            System.out.println("Consumer interrupted");
        }
    }
}