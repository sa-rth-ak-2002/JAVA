public class Main {
    public static void main(String[] args) {
        FoodBuffer buffer = new FoodBuffer(10);
        Producer producer = new Producer(buffer);
        Consumer consumer = new Consumer(buffer);

        producer.start();
        consumer.start();
    }
}