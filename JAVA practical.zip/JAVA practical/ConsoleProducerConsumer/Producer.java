public class Producer extends Thread {
    private final FoodBuffer buffer;

    public Producer(FoodBuffer buffer) {
        this.buffer = buffer;
    }

    public void run() {
        try {
            while (true) {
                Food food = new Food(FoodType.values()[(int)(Math.random() * 4)]);
                buffer.produce(food);
                buffer.displayBuffer();
                Thread.sleep((int)(Math.random() * 3000));
            }
        } catch (InterruptedException e) {
            System.out.println("Producer interrupted");
        }
    }
}