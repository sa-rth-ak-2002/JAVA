public class Food {
    FoodType type;

    public Food(FoodType type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return type.name();
    }
}