
public class FactoryMain {
	public static void main(String tanmoy[]) {
		GetNotify obj= Fact.Notify(2);
		obj.Get();
		GetNotify obj1= Fact.Notify(3);
		obj1.Get();
		GetNotify obj2= Fact.Notify(1);
		obj2.Get();
	}
}
