
public interface GetNotify {
	void Get();
}
