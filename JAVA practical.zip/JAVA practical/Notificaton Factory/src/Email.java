
public class Email implements GetNotify {
	public void Get() {
		System.out.println("Email");
	}
}
