
public class SMS implements GetNotify{
	public void Get() {
		System.out.println("sms");
	}
}

