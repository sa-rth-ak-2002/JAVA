
public class Fact {

	public static GetNotify Notify(int num) {
		if(num==1) {
			return new Buzzer();
		}
		else if(num==2) {
			return new SMS();
		}
		else if(num==3) {
			return new Email();
		}
		else return null;
	}
}
