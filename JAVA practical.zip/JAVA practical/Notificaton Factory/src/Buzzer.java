
public class Buzzer implements GetNotify {
	public void Get() {
		System.out.println("Buzzer");
	}
}
