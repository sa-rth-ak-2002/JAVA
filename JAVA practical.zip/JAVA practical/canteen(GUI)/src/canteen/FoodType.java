package canteen;

public enum FoodType {
	MANGO, KIWI, PINEAPPLE, BANANA
}
