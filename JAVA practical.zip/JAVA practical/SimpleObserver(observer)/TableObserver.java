class TableObserver implements VisualizationObserver {
    public void update(String type, double a, double b, double c) {
        if (type.equalsIgnoreCase("Table")) {
            System.out.println("Table View:");
            System.out.println("a\tb\tc");
            System.out.println(a + "\t" + b + "\t" + c);
        }
    }
}