interface VisualizationObserver {
    void update(String type, double a, double b, double c);
}