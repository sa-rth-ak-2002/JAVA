import java.util.ArrayList;

class VisualizationSubject {
    private ArrayList<VisualizationObserver> observers = new ArrayList<>();

    public void addObserver(VisualizationObserver observer) {
        observers.add(observer);
    }

    public void setState(String type, double a, double b, double c) {
        for (VisualizationObserver observer : observers) {
            observer.update(type, a, b, c);
        }
    }
}