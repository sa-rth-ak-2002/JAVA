import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        VisualizationSubject subject = new VisualizationSubject();
        subject.addObserver(new PieChartObserver());
        subject.addObserver(new TableObserver());

        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter value for a: ");
        double a = scanner.nextDouble();

        System.out.print("Enter value for b: ");
        double b = scanner.nextDouble();

        System.out.print("Enter value for c: ");
        double c = scanner.nextDouble();

        System.out.print("Choose display type (Pie Chart / Table): ");
        scanner.nextLine(); // consume newline
        String type = scanner.nextLine();

        subject.setState(type, a, b, c);
    }
}