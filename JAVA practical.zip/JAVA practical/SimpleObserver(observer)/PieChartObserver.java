class PieChartObserver implements VisualizationObserver {
    public void update(String type, double a, double b, double c) {
        if (type.equalsIgnoreCase("Pie Chart")) {
            System.out.println("Pie Chart: a = " + a + ", b = " + b + ", c = " + c);
        }
    }
}