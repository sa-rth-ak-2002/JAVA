public class BuzzerNotification implements Notification {
    private static BuzzerNotification instance = null;

    private BuzzerNotification() {}

    public static BuzzerNotification getInstance() {
        if (instance == null) {
            instance = new BuzzerNotification();
        }
        return instance;
    }

    @Override
    public void notifyUser() {
        System.out.println("Playing Buzzer to notify clients...");
    }
}