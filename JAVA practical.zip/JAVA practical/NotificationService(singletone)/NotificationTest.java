public class NotificationTest {
    public static void main(String[] args) {
        // Send SMS Notification
        NotificationService service1 = new NotificationService(SMSNotification.getInstance());
        service1.sendNotification();

        // Send Email Notification
        NotificationService service2 = new NotificationService(EmailNotification.getInstance());
        service2.sendNotification();

        // Send Buzzer Notification
        NotificationService service3 = new NotificationService(BuzzerNotification.getInstance());
        service3.sendNotification();
    }
}