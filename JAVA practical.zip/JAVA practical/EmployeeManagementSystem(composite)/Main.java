import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        CompositeEmployee ceo = new CompositeEmployee("Alice (CEO)", 100000);

        CompositeEmployee manager1 = new CompositeEmployee("Bob (Manager - IT)", 50000);
        CompositeEmployee leader1 = new CompositeEmployee("Charlie (Leader)", 30000);
        Employee worker1 = new Worker("Dave (Worker)", 20000);
        Employee worker2 = new Worker("Eva (Worker)", 20000);

        leader1.add(worker1);
        manager1.add(leader1);
        manager1.add(worker2);
        ceo.add(manager1);

        String[] options = {
            "Add Employee",
            "Remove Employee",
            "Promote Employee",
            "Total Salary",
            "Total Employees",
            "View Details",
            "Exit"
        };

        while (true) {
            int choice = JOptionPane.showOptionDialog(null, "Choose an action", "EMS",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE,
                    null, options, options[0]);

            switch (choice) {
                case 3:
                    JOptionPane.showMessageDialog(null, "Total Salary: " + ceo.getSalary());
                    break;
                case 4:
                    JOptionPane.showMessageDialog(null, "Total Employees: " + ceo.getEmployeeCount());
                    break;
                case 5:
                    JOptionPane.showMessageDialog(null, ceo.getDetails());
                    break;
                case 6:
                    System.exit(0);
            }
        }
    }
}