import java.util.ArrayList;
import java.util.List;

public class CompositeEmployee extends Employee {
    private List<Employee> subordinates = new ArrayList<>();

    public CompositeEmployee(String name, double salary) {
        super(name, salary);
    }

    public void add(Employee e) {
        subordinates.add(e);
    }

    public void remove(Employee e) {
        subordinates.remove(e);
    }

    public double getSalary() {
        double total = salary;
        for (Employee e : subordinates) {
            total += e.getSalary();
        }
        return total;
    }

    public int getEmployeeCount() {
        int count = 1;
        for (Employee e : subordinates) {
            count += e.getEmployeeCount();
        }
        return count;
    }

    public String getDetails() {
        StringBuilder sb = new StringBuilder();
        sb.append("Employee: ").append(name).append(", Salary: ").append(salary).append("\n");
        for (Employee e : subordinates) {
            sb.append("  ").append(e.getDetails()).append("\n");
        }
        return sb.toString();
    }
}