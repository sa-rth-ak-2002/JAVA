import java.util.List;

public abstract class Employee {
    protected String name;
    protected double salary;

    public Employee(String name, double salary) {
        this.name = name;
        this.salary = salary;
    }

    public abstract void add(Employee e);
    public abstract void remove(Employee e);
    public abstract double getSalary();
    public abstract int getEmployeeCount();
    public abstract String getDetails();
}