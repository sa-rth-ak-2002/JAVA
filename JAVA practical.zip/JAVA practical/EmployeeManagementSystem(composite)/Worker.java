public class Worker extends Employee {

    public Worker(String name, double salary) {
        super(name, salary);
    }

    public void add(Employee e) {
        // Not applicable for leaf
    }

    public void remove(Employee e) {
        // Not applicable for leaf
    }

    public double getSalary() {
        return salary;
    }

    public int getEmployeeCount() {
        return 1;
    }

    public String getDetails() {
        return "Worker: " + name + ", Salary: " + salary;
    }
}