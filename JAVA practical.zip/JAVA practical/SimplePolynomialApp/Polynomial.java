public class Polynomial {
    private int[] coeffs = new int[100]; // index = exponent, value = coefficient

    public void addTerm(int coeff, int exp) {
        coeffs[exp] += coeff;
    }

    public Polynomial add(Polynomial other) {
        Polynomial result = new Polynomial();
        for (int i = 0; i < coeffs.length; i++) {
            result.coeffs[i] = this.coeffs[i] + other.coeffs[i];
        }
        return result;
    }

    public Polynomial subtract(Polynomial other) {
        Polynomial result = new Polynomial();
        for (int i = 0; i < coeffs.length; i++) {
            result.coeffs[i] = this.coeffs[i] - other.coeffs[i];
        }
        return result;
    }

    public int evaluate(int x) {
        int result = 0;
        for (int i = 0; i < coeffs.length; i++) {
            result += coeffs[i] * Math.pow(x, i);
        }
        return result;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (int i = coeffs.length - 1; i >= 0; i--) {
            if (coeffs[i] != 0) {
                if (sb.length() > 0 && coeffs[i] > 0) sb.append("+");
                sb.append(coeffs[i]);
                if (i > 0) sb.append("x");
                if (i > 1) sb.append("^").append(i);
            }
        }
        return sb.length() > 0 ? sb.toString() : "0";
    }
}