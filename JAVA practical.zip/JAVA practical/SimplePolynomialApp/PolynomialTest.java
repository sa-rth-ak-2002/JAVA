import javax.swing.JOptionPane;

public class PolynomialTest {
    public static void main(String[] args) {
        Polynomial p1 = new Polynomial();
        Polynomial p2 = new Polynomial();

        int terms1 = Integer.parseInt(JOptionPane.showInputDialog("Enter number of terms in Polynomial 1:"));
        for (int i = 0; i < terms1; i++) {
            int coeff = Integer.parseInt(JOptionPane.showInputDialog("P1 - Term " + (i+1) + " coefficient:"));
            int exp = Integer.parseInt(JOptionPane.showInputDialog("P1 - Term " + (i+1) + " exponent:"));
            p1.addTerm(coeff, exp);
        }

        int terms2 = Integer.parseInt(JOptionPane.showInputDialog("Enter number of terms in Polynomial 2:"));
        for (int i = 0; i < terms2; i++) {
            int coeff = Integer.parseInt(JOptionPane.showInputDialog("P2 - Term " + (i+1) + " coefficient:"));
            int exp = Integer.parseInt(JOptionPane.showInputDialog("P2 - Term " + (i+1) + " exponent:"));
            p2.addTerm(coeff, exp);
        }

        Polynomial sum = p1.add(p2);
        Polynomial diff = p1.subtract(p2);
        int xVal = Integer.parseInt(JOptionPane.showInputDialog("Enter a value of x to evaluate:"));
        int eval1 = p1.evaluate(xVal);
        int eval2 = p2.evaluate(xVal);

        String result = "Polynomial 1: " + p1 + "\n" +
                        "Polynomial 2: " + p2 + "\n\n" +
                        "Sum: " + sum + "\n" +
                        "Difference (P1 - P2): " + diff + "\n\n" +
                        "P1 at x=" + xVal + ": " + eval1 + "\n" +
                        "P2 at x=" + xVal + ": " + eval2;

        JOptionPane.showMessageDialog(null, result);
    }
}