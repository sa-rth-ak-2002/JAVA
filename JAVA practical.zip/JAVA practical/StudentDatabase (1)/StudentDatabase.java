import java.io.*;
import java.util.*;

public class StudentDatabase {
    public List<Student> students = new ArrayList<>();
    public List<Mark> marks = new ArrayList<>();
    final String FILE = "student.txt";

    public StudentDatabase() {
        loadData();
    }

    public void addStudent(String id, String name, int age) {
        students.add(new Student(id, name, age));
        saveData();
    }

    public void addMark(String studentId, String subject, int marksValue) {
        marks.add(new Mark(studentId, subject, marksValue));
        saveData();
    }

    public void viewAll() {
        for (Student s : students) {
            System.out.println("ID: " + s.id + ", Name: " + s.name + ", Age: " + s.age);
            for (Mark m : marks) {
                if (m.studentId.equals(s.id)) {
                    System.out.println("   Subject: " + m.subject + ", Marks: " + m.marks);
                }
            }
        }
    }

    public boolean updateStudent(String id, String newName, int newAge) {
        for (Student s : students) {
            if (s.id.equals(id)) {
                s.name = newName;
                s.age = newAge;
                saveData();
                return true;
            }
        }
        return false;
    }

    public boolean deleteStudent(String id) {
        boolean removed = students.removeIf(s -> s.id.equals(id));
        marks.removeIf(m -> m.studentId.equals(id));
        saveData();
        return removed;
    }

    private void loadData() {
        File file = new File(FILE);
        if (!file.exists()) return;

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            boolean readingStudents = true;

            while ((line = br.readLine()) != null) {
                if (line.equals("---")) {
                    readingStudents = false;
                    continue;
                }
                String[] parts = line.split(",");
                if (readingStudents && parts.length == 3) {
                    students.add(new Student(parts[0], parts[1], Integer.parseInt(parts[2])));
                } else if (!readingStudents && parts.length == 3) {
                    marks.add(new Mark(parts[0], parts[1], Integer.parseInt(parts[2])));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void saveData() {
        try (PrintWriter pw = new PrintWriter(new FileWriter(FILE))) {
            for (Student s : students) pw.println(s);
            pw.println("---");
            for (Mark m : marks) pw.println(m);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}