public class Mark {
    String studentId, subject;
    int marks;

    public Mark(String studentId, String subject, int marks) {
        this.studentId = studentId;
        this.subject = subject;
        this.marks = marks;
    }

    @Override
    public String toString() {
        return studentId + "," + subject + "," + marks;
    }
}