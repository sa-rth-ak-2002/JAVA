import javax.swing.JOptionPane;
import java.io.*;
import java.util.ArrayList;

public class FactorialTest {
    public static void main(String[] args) {
        try {
            String input = JOptionPane.showInputDialog("Enter the value of i (1 to 10):");
            int i = Integer.parseInt(input);

            BufferedReader reader = new BufferedReader(new FileReader("numbers.txt"));
            ArrayList<Integer> numbers = new ArrayList<>();
            String line;
            while ((line = reader.readLine()) != null) {
                numbers.add(Integer.parseInt(line));
            }
            reader.close();

            if (i < 1 || i > numbers.size()) {
                JOptionPane.showMessageDialog(null, "Invalid input. i should be between 1 and " + numbers.size());
                return;
            }

            int n = numbers.get(i - 1);

            FactUtil factUtil = FactUtil.getInstance();
            int result = factUtil.factorial(n);

            JOptionPane.showMessageDialog(null, "Factorial of " + n + " is " + result);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
    }
}